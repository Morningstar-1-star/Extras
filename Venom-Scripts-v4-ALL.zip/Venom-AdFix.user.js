// ==UserScript==
// @name         Venom AdFix – Anti-Adblock Defeater (per-site)
// @namespace    venom.adfix
// @version      1.2.0
// @description  For sites that say "turn off adblock" and leave the video blank: makes blocked ad checks look successful, hides click-hijack overlays, re-clicks the site's "check again" button, and has a Report + tap-to-hide tool. Runs ONLY on sites you enable (default: sextb.net).
// @match        http://*/*
// @match        https://*/*
// @run-at       document-start
// @noframes
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_registerMenuCommand
// ==/UserScript==

(function () {
  'use strict';
  const W = window, D = document, H = location.hostname.replace(/^www\./, '').toLowerCase();
  if (/\/cdn-cgi\/|[?&]__cf_chl_/.test(location.href)) return; // Cloudflare check page: touch nothing

  const get = (k, d) => { try { const v = GM_getValue(k, d); return v == null ? d : v; } catch (e) { return d; } };
  const put = (k, v) => { try { GM_setValue(k, v); } catch (e) {} };
  const menu = (n, f) => { try { GM_registerMenuCommand(n, f); } catch (e) {} };

  // ---- per-site switch (nothing is touched on sites that are not enabled) ----
  let sites = get('af_sites', null);
  if (!Array.isArray(sites)) sites = ['sextb.net'];
  const match = s => H === s || H.endsWith('.' + s);
  const ON = sites.some(match);
  menu(ON ? 'AdFix: turn OFF for ' + H : 'AdFix: turn ON for ' + H, () => {
    put('af_sites', ON ? sites.filter(s => !match(s)) : sites.concat(H));
    location.reload();
  });
  if (!ON) return;

  // ---- log (for the Report) ----
  const R = { fake: [], fail: [], fetch: [], xhr: [], hid: [], pop: [] };
  const add = (a, s) => { if (a.length < 80 && a.indexOf(s) < 0) a.push(String(s).slice(0, 200)); };

  // URLs that look like ads / ad checks (also same-site bait files like /ads.js)
  const AD_RE = /(^|[\/._?&=-])(ads?|adv|advert\w*|adserver|adsbygoogle|banners?|doubleclick|googlesyndication|googleadservices|pagead|popunder|popads|popcash|exoclick|exosrv|juicyads|trafficjunky|trafficfactory|adsterra|propeller\w*|clickadu|hilltopads|adcash|a-ads|realsrv|magsrv|tsyndicate|histats|adnxs|taboola|outbrain|onclick\w*|monetag|bidvertiser|yllix|plugrush|ero-advertising|adtng|trafficstars)([\/._?&=-]|$)/i;

  // any THIRD-PARTY request that fails also counts as "ad-like" (sites probe their own ad hosts, e.g. cbvbujjk.xyz)
  const KEEP = /(^|\.)(cloudflare\.com|jsdelivr\.net|zencdn\.net|gstatic\.com|googleapis\.com|f4scdn\.com|imggle\.net)$/i;
  const hostOf = u => { try { return new URL(u, location.href).hostname; } catch (e) { return ''; } };
  const third = u => { try { return new URL(u, location.href).host !== location.host; } catch (e) { return false; } };
  const adish = u => AD_RE.test(u) || (third(u) && !KEEP.test(hostOf(u)));

  // the site caches its answer for 10 min and reads it FIRST, so pre-seed "not blocked" before its code runs
  if (/(^|\.)sextb\.net$/.test(H)) { try { sessionStorage.setItem('sxab', JSON.stringify({ b: false, t: Date.now() })); } catch (e) {} }

  // ---- 1. blocked ad scripts / images / frames look like they LOADED ----
  W.addEventListener('error', function (e) {
    const t = e.target;
    if (!t || t === W || !t.tagName) return;
    const u = t.currentSrc || t.src || t.href || '';
    if (!u) return;
    if (adish(u)) {
      e.stopImmediatePropagation(); e.preventDefault();
      add(R.fake, t.tagName + ' ' + u);
      setTimeout(function () { try { t.dispatchEvent(new Event('load')); } catch (x) {} }, 0);
    } else add(R.fail, t.tagName + ' ' + u);
  }, true);

  // ---- 2. blocked fetch / XHR to ad URLs look like they SUCCEEDED ----
  try {
    const rf = W.fetch;
    W.fetch = function (input) {
      const u = typeof input === 'string' ? input : (input && input.url) || '';
      return rf.apply(this, arguments).then(function (r) { return r; }, function (err) {
        if (adish(u)) { add(R.fetch, 'fake-ok ' + u); return new Response('', { status: 200 }); }
        add(R.fetch, 'FAILED ' + u); throw err;
      });
    };
  } catch (e) {}
  try {
    const xo = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function (m, url) {
      const x = this, u = String(url || '');
      if (adish(u)) {
        x.addEventListener('error', function (ev) {
          ev.stopImmediatePropagation(); add(R.xhr, 'fake-ok ' + u);
          try { [['status', 200], ['readyState', 4], ['responseText', ''], ['response', '']].forEach(function (p) { Object.defineProperty(x, p[0], { value: p[1], configurable: true }); }); } catch (e2) {}
          ['readystatechange', 'load', 'loadend'].forEach(function (n) { try { x.dispatchEvent(new Event(n)); } catch (e3) {} });
        }, true);
      }
      return xo.apply(this, arguments);
    };
  } catch (e) {}
  try { W.canRunAds = true; } catch (e) {}

  // ---- 2b. pop-up guard: no new windows / tabs to other sites, click-hijack links included ----
  const popOk = !!get('af_popok', {})[H];
  menu(popOk ? 'AdFix: pop-ups ALLOWED here (tap to block)' : 'AdFix: pop-ups BLOCKED here (tap to allow)', function () { const m = get('af_popok', {}); m[H] = !popOk; put('af_popok', m); location.reload(); });
  if (!popOk) {
    const realOpen = W.open;
    W.open = function (u) {
      const h = hostOf(u || '');
      if (h && h === location.hostname) return realOpen.apply(W, arguments);
      add(R.pop, 'window.open ' + String(u || '(blank)').slice(0, 150));
      const noop = function () {};
      return { closed: true, focus: noop, blur: noop, close: noop, postMessage: noop, document: { write: noop, writeln: noop, close: noop, open: noop }, location: { href: '', replace: noop, assign: noop } };
    };
    W.addEventListener('click', function (e) {
      const a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
      if (!a) return;
      const h = hostOf(a.href);
      if (h && h !== location.hostname && a.target === '_blank' && !KEEP.test(h)) {
        e.preventDefault(); e.stopImmediatePropagation(); add(R.pop, 'link ' + a.href.slice(0, 150)); note('Blocked a pop-up link');
      }
    }, true);
  }

  // ---- 3. hide ads without blocking them: picked elements + click-hijack overlays ----
  const picks = get('af_hide', {}); const mine = picks[H] || [];
  const st = D.createElement('style'); st.id = '__af_css';
  const css = () => { st.textContent = (mine.length ? mine.join(',') + '{display:none!important}' : '') + 'ins.adsbygoogle{display:none!important}'; };
  css(); (D.head || D.documentElement).appendChild(st);

  function hasMedia(el) { try { return !!el.querySelector('video,canvas,input,textarea,select'); } catch (e) { return false; } }
  function sweep() {
    const vw = W.innerWidth, vh = W.innerHeight;
    D.querySelectorAll('body > *, body > * > *, iframe, a[target="_blank"]').forEach(function (el) {
      if (el.__afSeen) return;
      try {
        if (el.tagName === 'IFRAME' && (AD_RE.test(el.src || '') || /\/api\/spots\//.test(el.src || ''))) { el.style.setProperty('display', 'none', 'important'); el.__afSeen = 1; add(R.hid, 'iframe ' + el.src); return; }
        const cs = getComputedStyle(el);
        if (cs.position !== 'fixed' && cs.position !== 'absolute') return;
        const r = el.getBoundingClientRect();
        if (r.width < vw * 0.8 || r.height < vh * 0.6) return;
        if ((parseInt(cs.zIndex, 10) || 0) < 1000) return;
        if ((el.textContent || '').trim().length > 30 || hasMedia(el)) return;
        el.style.setProperty('display', 'none', 'important'); el.__afSeen = 1;
        add(R.hid, 'overlay ' + el.tagName + '.' + String(el.className).slice(0, 40));
      } catch (e) {}
    });
  }

  // ---- 3b. bait elements: if an ad blocker hid an empty element with an ad-like class, un-hide it so the site's visibility check passes ----
  const BAIT = /(^|[\s_-])(ads?|adsbox|ad-?banner|banner-?ads?|advert\w*|ad-?placement|ad-?unit|adsbygoogle|pub[_-]?\d+x\d+|text-?ads?|sponsor\w*|ad-?slot)([\s_-]|$)/i;
  function unbait(el) {
    try {
      if (!el || el.nodeType !== 1 || el.tagName === 'IFRAME' || el.tagName === 'SCRIPT') return;
      const k = String(typeof el.className === 'string' ? el.className : '') + ' ' + (el.id || '');
      if (!BAIT.test(k) || el.children.length || (el.textContent || '').trim()) return;
      const cs = getComputedStyle(el);
      if (cs.display !== 'none' && cs.visibility !== 'hidden' && cs.opacity !== '0') return;
      el.style.setProperty('display', 'block', 'important');
      el.style.setProperty('visibility', 'visible', 'important');
      el.style.setProperty('opacity', '1', 'important');
      add(R.hid, 'bait un-hidden ' + el.tagName + ' ' + k.trim().slice(0, 40));
    } catch (e) {}
  }
  try {
    new MutationObserver(function (ms) {
      ms.forEach(function (m) { if (m.type === 'attributes') unbait(m.target); else m.addedNodes.forEach(function (n) { unbait(n); if (n.querySelectorAll) n.querySelectorAll('[class],[id]').forEach(unbait); }); });
    }).observe(D, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class', 'hidden'] });
  } catch (e) {}

  // ---- 4. press the site's own "I've disabled it / check again" button once ads "load" ----
  const BTN = /(i['’]?ve\s+disabled\s+it|still\s+blocked|check\s+again)/i;
  function recheck() {
    const els = D.querySelectorAll('button,a,[role="button"],.btn');
    for (const el of els) {
      const t = (el.textContent || '').trim();
      if (t.length < 60 && BTN.test(t) && el.offsetParent !== null) { el.click(); return true; }
    }
    return false;
  }

  // ---- 5. tap-to-hide picker ----
  function cssPath(el) {
    const p = [];
    while (el && el.nodeType === 1 && el !== D.body && p.length < 5) {
      let s = el.tagName.toLowerCase();
      if (el.id) { p.unshift(s + '#' + CSS.escape(el.id)); break; }
      const c = Array.from(el.classList).filter(function (x) { return !/\d{4,}/.test(x); }).slice(0, 2);
      if (c.length) s += '.' + c.map(CSS.escape).join('.');
      const sib = el.parentElement ? Array.from(el.parentElement.children).filter(function (x) { return x.tagName === el.tagName; }) : [];
      if (sib.length > 1) s += ':nth-of-type(' + (sib.indexOf(el) + 1) + ')';
      p.unshift(s); el = el.parentElement;
    }
    return p.join(' > ');
  }
  function pick() {
    note('Tap the ad you want to hide');
    const h = function (e) {
      e.preventDefault(); e.stopImmediatePropagation();
      W.removeEventListener('click', h, true);
      const sel = cssPath(e.target);
      if (sel) { mine.push(sel); picks[H] = mine; put('af_hide', picks); css(); note('Hidden: ' + sel.slice(-40)); }
    };
    W.addEventListener('click', h, true);
  }
  menu('AdFix: tap an ad to hide it', pick);
  menu('AdFix: forget my hidden picks for this site', function () { delete picks[H]; put('af_hide', picks); location.reload(); });
  menu('AdFix: re-check now', function () { note(recheck() ? 'Clicked the site\'s check button' : 'No check button on screen'); });

  // ---- 6. Report: what the site really checks (send this to Claude) ----
  async function report() {
    const L = ['AdFix report  ' + location.href, 'UA: ' + navigator.userAgent, ''];
    const sec = function (t, a) { L.push('== ' + t + ' (' + a.length + ')'); a.forEach(function (x) { L.push('  ' + x); }); L.push(''); };
    sec('ad-like loads turned into "success"', R.fake);
    sec('other failed loads (not ad-like)', R.fail);
    sec('fetch', R.fetch); sec('xhr', R.xhr); sec('hidden by AdFix', R.hid); sec('pop-ups stopped', R.pop);
    let live = 'n/a'; try { live = typeof sxAb !== 'undefined' ? JSON.stringify(sxAb.now()) : 'sxAb not visible'; } catch (e) { live = 'err ' + e; }
    L.push('sxAb.now() = ' + live); L.push('sessionStorage.sxab = ' + (function () { try { return sessionStorage.getItem('sxab'); } catch (e) { return 'err'; } })()); L.push('');
    sec('scripts on page', Array.from(D.scripts).map(function (s) { return s.src || '(inline ' + (s.textContent || '').length + ' chars)'; }));
    sec('iframes', Array.from(D.querySelectorAll('iframe')).map(function (f) { return f.src || '(no src)'; }));
    const keys = [];
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); keys.push('local ' + k + ' = ' + String(localStorage.getItem(k)).slice(0, 40)); } } catch (e) {}
    try { for (let i = 0; i < sessionStorage.length; i++) { const k = sessionStorage.key(i); keys.push('session ' + k + ' = ' + String(sessionStorage.getItem(k)).slice(0, 40)); } } catch (e) {}
    try { document.cookie.split(';').forEach(function (c) { const n = c.split('=')[0].trim(); if (n) keys.push('cookie ' + n); }); } catch (e) {}
    sec('storage keys', keys);
    const RE = /Ad blocker detected|disable your ad blocker|function adblockBlocks|adblockBlocks\s*=|sxAb\.now\(|sxAb\.wait\(|sxAb\.recheck\(|sxabFree/ig;
    const hits = [];
    const grab = function (t, label) { let m, n = 0; RE.lastIndex = 0; while ((m = RE.exec(t)) && n++ < 8) { hits.push(label + ': …' + t.slice(Math.max(0, m.index - 250), m.index + 650).replace(/\s+/g, ' ') + '…'); RE.lastIndex = m.index + 700; } };
    Array.from(D.scripts).forEach(function (s, i) { if (!s.src) grab(s.textContent || '', 'inline#' + i); });
    for (const s of Array.from(D.scripts).filter(function (s) { return s.src; }).slice(0, 30)) {
      try { if (new URL(s.src).host === location.host) grab(await (await fetch(s.src, { credentials: 'include' })).text(), s.src); } catch (e) {}
    }
    sec('detection code found in this site\'s own scripts', hits);
    return L.join('\n');
  }
  async function showReport() {
    note('Building report…');
    const txt = await report();
    const box = D.createElement('div');
    box.style.cssText = 'position:fixed;inset:8px;z-index:2147483647;background:#111;color:#9fe8b8;border:1px solid #14b878;border-radius:10px;display:flex;flex-direction:column;padding:8px;font:11px monospace';
    const ta = D.createElement('textarea'); ta.value = txt; ta.readOnly = true;
    ta.style.cssText = 'flex:1;background:#000;color:#9fe8b8;border:1px solid #333;font:11px monospace';
    const row = D.createElement('div'); row.style.cssText = 'display:flex;gap:8px;margin-top:8px';
    const b = function (label, fn) { const x = D.createElement('button'); x.textContent = label; x.style.cssText = 'flex:1;padding:10px;border:0;border-radius:8px;background:#14b878;color:#000;font-weight:700'; x.onclick = fn; row.appendChild(x); };
    b('Copy', function () { ta.select(); try { D.execCommand('copy'); note('Copied'); } catch (e) {} });
    b('Close', function () { box.remove(); });
    box.appendChild(ta); box.appendChild(row); D.documentElement.appendChild(box);
  }
  menu('AdFix: show report (send to Claude)', showReport);

  function note(msg) {
    const t = D.createElement('div');
    t.textContent = 'AdFix: ' + msg;
    t.style.cssText = 'position:fixed;left:50%;bottom:80px;transform:translateX(-50%);z-index:2147483647;background:#14b878;color:#000;padding:10px 14px;border-radius:20px;font:600 14px system-ui;max-width:90%';
    (D.body || D.documentElement).appendChild(t); setTimeout(function () { t.remove(); }, 2500);
  }

  // small floating "AF" button so the Report works even without the script menu
  function pill() {
    if (!D.body) return;
    const p = D.createElement('div'); p.textContent = 'AF';
    p.style.cssText = 'position:fixed;left:6px;bottom:90px;z-index:2147483646;background:rgba(20,184,120,.75);color:#000;font:700 12px system-ui;padding:8px 10px;border-radius:14px;opacity:.7';
    p.onclick = showReport; D.body.appendChild(p);
  }

  let kicked = 0;
  // ---- run ----
  function start() {
    pill(); sweep();
    let n = 0; const iv = setInterval(function () { sweep(); if (++n > 40) clearInterval(iv); }, 1500);
    let kicks = 0; const iv3 = setInterval(function () {
      if (++kicks > 8 || kicked >= 2) return clearInterval(iv3);
      if (!/Ad blocker detected/i.test((D.body && D.body.innerText) || '')) return;
      const b = Array.from(D.querySelectorAll('a,button,[role="button"],.btn,div')).find(function (el) { return el.children.length < 3 && /^\s*(F4|SW|DD|FL|ST)\s*$/.test(el.textContent || '') && el.offsetParent !== null; });
      if (b) { kicked++; b.click(); note('Reloading the player…'); }
    }, 3000);
    let clicks = 0, misses = 0;
    const iv2 = setInterval(function () {
      if (recheck()) { clicks++; misses = 0; } else misses++;
      if (clicks >= 5 || misses >= 4) clearInterval(iv2);
    }, 3500);
  }
  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded', start, { once: true }); else start();
})();
