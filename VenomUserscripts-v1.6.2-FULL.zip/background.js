'use strict';
const DEFAULTS = { enabled: true, stripCsp: true, autoUpdate: true, updateHours: 24, blockIpLoggers: true, blockAds: true, adWhitelist: [], adTotal: 0, listDays: 3, cfSafe: true, redirectGuard: 'ads', redirectAllow: [], popupBlock: [], lists: { adservers: true, peterlowe: true }, customLists: [] };
const AD_DOMAINS = new Set(["2mdn.net", "33across.com", "a-ads.com", "ad-maven.com", "adcash.com", "adcolony.com", "adform.net", "admaven.com", "adnxs.com", "ads-twitter.com", "adsafeprotected.com", "adservice.google.com", "adspyglass.com", "adsrvr.org", "adsterra.com", "adtng.com", "amazon-adsystem.com", "applovin.com", "bidvertiser.com", "casalemedia.com", "clarity.ms", "clickadu.com", "clickaine.com", "crazyegg.com", "criteo.com", "criteo.net", "doubleclick.net", "effectivegatecpm.com", "ero-advertising.com", "exoclick.com", "exosrv.com", "fullstory.com", "google-analytics.com", "googleadservices.com", "googlesyndication.com", "googletagservices.com", "highperformanceformat.com", "hilltopads.net", "hotjar.com", "indexww.com", "inmobi.com", "juicyads.com", "magsrv.com", "media.net", "mgid.com", "moatads.com", "mouseflow.com", "onclickads.net", "onclkds.com", "openx.net", "outbrain.com", "pagead2.googlesyndication.com", "plugrush.com", "popads.net", "popcash.net", "profitablegatecpm.com", "propellerads.com", "pubmatic.com", "quantserve.com", "realsrv.com", "revcontent.com", "rubiconproject.com", "scorecardresearch.com", "sharethrough.com", "smartadserver.com", "taboola.com", "teads.tv", "trafficfactory.biz", "trafficjunky.net", "trafficstars.com", "tsyndicate.com", "yllix.com", "zemanta.com"]);
const IP_LOGGERS = ["viral.over-blog.com", "gyazo.in", "ps3cfw.com", "urlz.fr", "webpanel.space", "steamcommumity.com", "imgur.com.de", "fuglekos.com", "discord.kim", "prntcrs.com", "grabify.link", "leancoding.co", "stopify.co", "freegiftcards.co", "joinmy.site", "curiouscat.club", "catsnthings.fun", "catsnthings.com", "xn--yutube-iqc.com", "gyazo.nl", "yip.su", "iplogger.com", "iplogger.co", "iplogger.org", "iplogger.ru", "iplogger.info", "ipgraber.ru", "ipgrabber.ru", "2no.co", "02ip.ru", "iplis.ru", "iplo.ru", "ezstat.ru", "whatstheirip.com", "partpicker.shop", "sportshub.bar", "locations.quest", "lovebird.guru", "trulove.guru", "dateing.club", "shrekis.life", "headshot.monster", "gaming-at-my.best", "progaming.monster", "yourmy.monster", "imageshare.best", "screenshot.best", "gamingfun.me", "catsnthing.com", "fortnitechat.site", "fortnight.space", "hondachat.com", "bvog.com", "youramonkey.com", "pronosparadise.com", "freebooter.pro", "blasze.com", "blasze.tk", "ipgrab.org", "gyazos.com"];
const allowed = new Map();
const LISTS = [
  { id: 'adservers', name: 'EasyList ad servers (~50k domains)', url: 'https://raw.githubusercontent.com/easylist/easylist/master/easylist/easylist_adservers.txt' },
  { id: 'peterlowe', name: "Peter Lowe's ad & tracking hosts", url: 'https://pgl.yoyo.org/adservers/serverlist.php?hostformat=hosts&showintro=0&mimetype=plaintext' },
  { id: 'thirdparty', name: 'EasyList third-party (domains only)', url: 'https://raw.githubusercontent.com/easylist/easylist/master/easylist/easylist_thirdparty.txt' },
  { id: 'trackers', name: 'EasyPrivacy tracking servers', url: 'https://raw.githubusercontent.com/easylist/easylist/master/easyprivacy/easyprivacy_trackingservers.txt' },
  { id: 'ublock', name: 'uBlock filters (domain rules only)', url: 'https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/filters/filters.txt' }
];
let adSet = new Set(AD_DOMAINS), popupSet = new Set();
const listCache = {}, LOG = [], stats = {}, lastGesture = {}, prevHost = {};
function allLists() { return LISTS.concat((settings.customLists || []).map(c => ({ id: c.id, name: c.name, url: c.url, custom: true }))); }
function listOn(id) { return !!(settings.lists && settings.lists[id]); }
function rebuildAdSet() {
  adSet = new Set(AD_DOMAINS); popupSet = new Set();
  for (const L of allLists()) { const c = listCache[L.id]; if (!c || !listOn(L.id)) continue; c.hosts.forEach(h => adSet.add(h)); c.popup.forEach(h => popupSet.add(h)); }
}
function logEntry(e) { LOG.push(Object.assign({ t: Date.now() }, e)); if (LOG.length > 300) LOG.shift(); }
async function updateLists(force) {
  const out = { ok: 0, fail: 0 };
  for (const L of allLists()) {
    if (!listOn(L.id)) continue;
    const c = listCache[L.id];
    if (!force && c && Date.now() - c.t < (settings.listDays || 3) * 86400000 - 3600000) continue;
    try {
      const r = await fetch(L.url, { cache: 'no-cache' });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const p = parseList(await r.text());
      if (!p.hosts.length && !p.popup.length) throw new Error('no domain rules found');
      listCache[L.id] = { hosts: p.hosts, popup: p.popup, t: Date.now() };
      await sset({ ['fl:' + L.id]: listCache[L.id] }); out.ok++;
    } catch (e) { out.fail++; logEntry({ level: 'warn', name: 'Filter list', msg: L.name + ': ' + e.message }); }
  }
  rebuildAdSet();
  return out;
}
let settings = Object.assign({}, DEFAULTS);
const scripts = {}, rules = {}, reqCache = {}, valCache = {};
const xhrs = new Map(), saveTimers = {};
const sget = k => new Promise(r => chrome.storage.local.get(k, r));
const sset = o => new Promise(r => chrome.storage.local.set(o, r));
const srem = k => new Promise(r => chrome.storage.local.remove(k, r));
const uid = () => 'u' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const noHash = u => u.split('#')[0];
const abs = (u, base) => { try { return noHash(new URL(u, base || undefined).href); } catch (e) { return noHash(u); } };

const ready = (async () => {
  const all = await sget(null);
  if (all.settings) Object.assign(settings, all.settings);
  for (const k in all) {
    if (k.startsWith('s:')) { const s = all[k]; scripts[s.id] = s; rules[s.id] = compileRules(s.meta); }
    else if (k.startsWith('r:')) reqCache[k.slice(2)] = all[k];
    else if (k.startsWith('v:')) valCache[k.slice(2)] = all[k];
    else if (k.startsWith('fl:')) listCache[k.slice(3)] = all[k];
  }
  rebuildAdSet();
  scheduleUpdates();
  if (allLists().some(L => listOn(L.id) && !listCache[L.id])) updateLists(false);
})();

async function fetchText(url) {
  const r = await fetch(url, { cache: 'no-cache' });
  if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + url);
  return r.text();
}

const cfFrames = {};
const CF_HOST = /(^|\.)challenges\.cloudflare\.com$/i;
function cfFrame(d) {
  if (settings.cfSafe === false) return false;
  const rh = d.responseHeaders || [];
  if (rh.some(h => /^cf-mitigated$/i.test(h.name))) return true;
  let u = null; try { u = new URL(d.url); } catch (e) {}
  if (u && (CF_HOST.test(u.hostname) || /\/cdn-cgi\/|[?&]__cf_chl_/.test(u.pathname + u.search))) return true;
  // Cloudflare interstitial: 403/429/503 answered by Cloudflare itself
  return [403, 429, 503].includes(d.statusCode) && rh.some(h => /^server$/i.test(h.name) && /cloudflare/i.test(h.value || ''));
}
const hostOf = url => { try { return new URL(url).hostname.replace(/^www\./, '').toLowerCase(); } catch (e) { return ''; } };
const isExcl = (s, h) => !!(s.excl && h && s.excl.some(x => h === x || h.endsWith('.' + x)));
function matches(s, url, ignoreExcl) {
  const r = rules[s.id];
  return !!r && r.inc.some(f => f(url)) && !r.exc.some(f => f(url)) && (ignoreExcl || !isExcl(s, hostOf(url)));
}
function scriptsFor(url, top, onlyEnabled = true) {
  if (onlyEnabled && !settings.enabled) return [];
  return Object.values(scripts).filter(s => (!onlyEnabled || s.enabled) && (top || !s.meta.noframes) && matches(s, url, !onlyEnabled));
}

// ---------- install / update ----------
async function install(code, o = {}) {
  const meta = parseMeta(code);
  if (!meta || !meta.name) throw new Error('Not a valid userscript (needs ==UserScript== block with @name)');
  let id = o.id;
  if (!id) {
    const ex = Object.values(scripts).find(s => s.meta.name === meta.name && s.meta.namespace === meta.namespace);
    id = ex ? ex.id : uid();
  }
  let syntaxError = '';
  try { new Function(code); } catch (e) { syntaxError = e.message; }
  const old = scripts[id];
  const base = o.url || (old && old.source) || '';
  const requires = [];
  for (const ru of meta.require) {
    const u = abs(ru, base);
    requires.push(u);
    if (o.bundle && o.bundle[u] != null) reqCache[u] = o.bundle[u];
    else if (o.fresh || reqCache[u] == null) {
      try { reqCache[u] = await fetchText(u); }
      catch (e) { if (reqCache[u] == null) throw new Error('@require failed: ' + u + ' (' + e.message + ')'); }
    }
    await sset({ ['r:' + u]: reqCache[u] });
  }
  const res = {};
  for (const line of meta.resource || []) {
    const m = line.match(/^(\S+)\s+(\S+)/); if (!m) continue;
    const url = abs(m[2], base);
    try {
      const r = await fetch(url, { cache: 'no-cache' }); if (!r.ok) throw new Error('HTTP ' + r.status);
      const ct = r.headers.get('content-type') || '', buf = await r.arrayBuffer();
      if (buf.byteLength > 800000) { res[m[1]] = { url }; continue; }
      res[m[1]] = /text|json|javascript|xml|css/.test(ct) ? { url, text: new TextDecoder().decode(buf) } : { url, data: 'data:' + (ct || 'application/octet-stream') + ';base64,' + b64(buf) };
    } catch (e) { res[m[1]] = { url }; }
  }
  const s = {
    id, code, meta, requires, res, fav: old ? !!old.fav : false,
    enabled: o.enabled !== undefined && !old ? o.enabled : (old ? old.enabled : true),
    source: o.url || (old && old.source) || meta.downloadURL || '',
    edited: !!o.edited, syntaxError,
    excl: old ? old.excl : [],
    installedAt: old ? old.installedAt : Date.now(),
    updatedAt: Date.now(), lastCheck: old ? old.lastCheck : 0
  };
  scripts[id] = s; rules[id] = compileRules(meta);
  await sset({ ['s:' + id]: s });
  if (o.values && !valCache[id]) { valCache[id] = o.values; await sset({ ['v:' + id]: o.values }); }
  return s;
}

async function installFromUrl(url) {
  const code = await fetchText(url);
  return install(code, { url, fresh: true });
}

async function checkUpdate(id, force) {
  const s = scripts[id];
  if (!s) return { status: 'missing' };
  if (s.edited && !force) return { status: 'edited' };
  const dl = s.meta.downloadURL || s.source, up = s.meta.updateURL || dl;
  if (!dl && !up) return { status: 'nourl' };
  const from = s.meta.version;
  try {
    let remote = null;
    if (up && up !== dl) { try { const m = parseMeta(await fetchText(up)); if (m) remote = m.version; } catch (e) {} }
    s.lastCheck = Date.now();
    if (remote !== null && cmpVersion(remote, from) <= 0) { await sset({ ['s:' + id]: s }); return { status: 'uptodate', version: from }; }
    const code = await fetchText(dl || up);
    const m = parseMeta(code);
    if (!m) throw new Error('Invalid script at update URL');
    if (remote === null && cmpVersion(m.version, from) <= 0 && !force) { await sset({ ['s:' + id]: s }); return { status: 'uptodate', version: from }; }
    await install(code, { id, url: dl || up, fresh: true });
    return { status: 'updated', from, to: m.version };
  } catch (e) { return { status: 'error', error: e.message }; }
}

async function updateAll() {
  const res = { updated: 0, uptodate: 0, errors: 0, skipped: 0, details: [] };
  for (const id of Object.keys(scripts)) {
    const r = await checkUpdate(id);
    if (r.status === 'updated') { res.updated++; res.details.push(scripts[id].meta.name + ' → ' + r.to); }
    else if (r.status === 'uptodate') res.uptodate++;
    else if (r.status === 'error') { res.errors++; res.details.push(scripts[id].meta.name + ': ' + r.error); }
    else res.skipped++;
  }
  settings.lastUpdateRun = Date.now(); await sset({ settings });
  return res;
}

function scheduleUpdates() {
  chrome.alarms.create('um-lists', { delayInMinutes: 30, periodInMinutes: Math.max(360, (settings.listDays || 3) * 1440) });
  chrome.alarms.clear('um-update', () => {
    if (settings.autoUpdate) chrome.alarms.create('um-update', { delayInMinutes: 5, periodInMinutes: Math.max(60, settings.updateHours * 60) });
  });
}
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'um-update') ready.then(() => settings.autoUpdate && updateAll()); if (a.name === 'um-lists') ready.then(() => updateLists(false)); });

// ---------- zip import ----------
function decodeValues(data) {
  const out = {};
  for (const k in data || {}) {
    let v = data[k];
    try {
      if (typeof v === 'string' && v.length) {
        const t = v[0], r = v.slice(1);
        if (t === 'o') v = JSON.parse(r); else if (t === 'n') v = Number(r); else if (t === 'b') v = r === 'true'; else if (t === 's') v = r;
      }
    } catch (e) {}
    out[k] = v;
  }
  return out;
}

async function importZip(ab) {
  const zip = await JSZip.loadAsync(ab);
  const names = Object.keys(zip.files).filter(n => !zip.files[n].dir);
  const out = { imported: [], errors: [] };
  const list = names.filter(n => /\.user\.js$/i.test(n));
  if (!list.length) throw new Error('No .user.js files found in zip');
  for (const n of list) {
    try {
      const code = await zip.file(n).async('string');
      const base = n.replace(/\.user\.js$/i, '');
      const bundle = {};
      for (const rn of names) {
        if (rn.startsWith(n + '-') && rn.endsWith('.requires.json')) {
          const info = JSON.parse(await zip.file(rn).async('string'));
          const fn = rn.slice(0, -'.requires.json'.length);
          if (info.url && zip.file(fn)) bundle[abs(info.url)] = await zip.file(fn).async('string');
        }
      }
      let values, enabled = true, url = '';
      if (zip.file(base + '.storage.json')) { try { const j = JSON.parse(await zip.file(base + '.storage.json').async('string')); values = decodeValues(j.data); } catch (e) {} }
      if (zip.file(base + '.options.json')) { try { const j = JSON.parse(await zip.file(base + '.options.json').async('string')); if (j.settings && j.settings.enabled === false) enabled = false; if (j.meta && j.meta.file_url) url = j.meta.file_url; } catch (e) {} }
      const s = await install(code, { bundle, values, enabled, url });
      out.imported.push(s.meta.name);
    } catch (e) { out.errors.push(n + ': ' + e.message); }
  }
  return out;
}

// ---------- API for UI pages ----------
window.api = {
  ready,
  getSettings: () => settings,
  async setSettings(p) { Object.assign(settings, p); await sset({ settings }); scheduleUpdates(); },
  list: () => Object.values(scripts).sort((a, b) => a.meta.name.localeCompare(b.meta.name)),
  matching: url => scriptsFor(url, true, false),
  isExcluded: (id, host) => isExcl(scripts[id], host),
  async setSiteExcluded(id, host, on) {
    const s = scripts[id], w = new Set(s.excl || []); if (on) w.add(host); else { [...w].forEach(x => { if (host === x || host.endsWith('.' + x)) w.delete(x); }); }
    s.excl = [...w]; await sset({ ['s:' + id]: s });
  },
  async setEnabled(id, v) { scripts[id].enabled = v; await sset({ ['s:' + id]: scripts[id] }); },
  async remove(id) { delete scripts[id]; delete rules[id]; delete valCache[id]; await srem(['s:' + id, 'v:' + id]); },
  async preview(url) { const code = await fetchText(url); const meta = parseMeta(code); if (!meta) throw new Error('Not a userscript'); return { code, meta }; },
  install, installFromUrl, checkUpdate, updateAll, importZip,
  async clearRequireCache() { const k = Object.keys(reqCache).map(u => 'r:' + u); k.forEach(x => delete reqCache[x.slice(2)]); await srem(k); return k.length; },
  getLists: () => allLists().map(L => ({ id: L.id, name: L.name, url: L.url, custom: !!L.custom, on: listOn(L.id), count: listCache[L.id] ? listCache[L.id].hosts.length + listCache[L.id].popup.length : 0, updated: listCache[L.id] ? listCache[L.id].t : 0 })),
  adSetSize: () => adSet.size,
  async setList(id, on) { settings.lists = Object.assign({}, settings.lists, { [id]: on }); await sset({ settings }); if (on && !listCache[id]) await updateLists(false); else rebuildAdSet(); },
  async addList(url, name) { const id = 'c' + Date.now().toString(36); settings.customLists = (settings.customLists || []).concat({ id, name: name || url.replace(/^https?:\/\//, '').slice(0, 40), url }); settings.lists = Object.assign({}, settings.lists, { [id]: true }); await sset({ settings }); return updateLists(false); },
  async removeList(id) { settings.customLists = (settings.customLists || []).filter(c => c.id !== id); delete listCache[id]; await srem('fl:' + id); await sset({ settings }); rebuildAdSet(); },
  updateLists,
  getLog: () => LOG.slice().reverse(),
  clearLog: () => { LOG.length = 0; Object.keys(stats).forEach(k => delete stats[k]); },
  getStats: () => stats,
  async setFav(id, v) { scripts[id].fav = v; await sset({ ['s:' + id]: scripts[id] }); },
  async setRedirectAllow(host, on) { const w = new Set(settings.redirectAllow || []); if (on) w.add(host); else w.delete(host); settings.redirectAllow = [...w]; await sset({ settings }); },
  siteScripts: host => scriptsFor('https://' + host + '/', true, false).map(s => ({ id: s.id, name: s.meta.name, enabled: s.enabled, excluded: isExcl(s, host), fav: !!s.fav })),
  sites() {
    const m = {};
    Object.values(scripts).forEach(s => (s.excl || []).forEach(h => { (m[h] = m[h] || { host: h, scripts: [] }).scripts.push(s.meta.name); }));
    (settings.adWhitelist || []).forEach(h => { (m[h] = m[h] || { host: h, scripts: [] }).ads = true; });
    (settings.redirectAllow || []).forEach(h => { (m[h] = m[h] || { host: h, scripts: [] }).redirect = true; });
    return Object.values(m);
  },
  async saveCode(id, code) { return install(code, { id, edited: true }); }
};

// ---------- content script messaging ----------
chrome.runtime.onMessage.addListener((msg, sender, send) => {
  const tab = sender.tab || {};
  if (msg.type === 'getScripts') {
    ready.then(() => {
      if (settings.cfSafe !== false && ((cfFrames[tab.id + ':' + sender.frameId] || 0) > Date.now() - 180000 || CF_HOST.test(hostOf(msg.url)))) { send({ scripts: [], guard: false }); return; }
      const list = scriptsFor(msg.url, sender.frameId === 0).map(s => ({
        id: s.id, name: s.meta.name, runAt: s.meta.runAt || 'document-idle', grants: s.meta.grant,
        values: valCache[s.id] || {},
        info: { name: s.meta.name, version: s.meta.version, namespace: s.meta.namespace, description: s.meta.description, author: s.meta.author, matches: s.meta.match, includes: s.meta.include, excludes: s.meta.exclude, grant: s.meta.grant, runAt: s.meta.runAt },
        resources: s.res || {},
        code: s.requires.map(u => reqCache[u] || '').join('\n;\n') + '\n;\n' + s.code
      }));
      send({ scripts: list, guard: settings.redirectGuard === 'strict' });
    });
    return true;
  }
  if (msg.type === 'gesture') { lastGesture[tab.id] = Date.now(); return; }
  if (msg.type === 'log') {
    const s = scripts[msg.sid], st = stats[msg.sid] || (stats[msg.sid] = { runs: 0, errors: 0, ms: 0, max: 0 });
    if (msg.kind === 'run') { st.runs++; st.ms += msg.ms || 0; st.max = Math.max(st.max, msg.ms || 0); if ((msg.ms || 0) > 150) logEntry({ level: 'warn', sid: msg.sid, name: s && s.meta.name, msg: 'slow start: ' + Math.round(msg.ms) + ' ms', host: msg.host }); }
    else { if (msg.level === 'error') st.errors++; logEntry({ level: msg.level || 'info', sid: msg.sid, name: s && s.meta.name, msg: msg.msg, host: msg.host }); }
    return;
  }
  if (msg.type === 'setValue' || msg.type === 'delValue') {
    const v = valCache[msg.id] || (valCache[msg.id] = {});
    if (msg.type === 'setValue') v[msg.k] = msg.v; else delete v[msg.k];
    clearTimeout(saveTimers[msg.id]);
    saveTimers[msg.id] = setTimeout(() => sset({ ['v:' + msg.id]: valCache[msg.id] }), 300);
    return;
  }
  if (msg.type === 'openInTab') {
    const o = msg.opts || {};
    const active = typeof o === 'boolean' ? !o : (o.active !== undefined ? !!o.active : !o.loadInBackground);
    chrome.tabs.create({ url: msg.url, active, openerTabId: tab.id, index: (tab.index || 0) + 1 });
    return;
  }
  if (msg.type === 'xhr') { runXhr(msg, sender).then(send); return true; }
  if (msg.type === 'xhrAbort') { const c = xhrs.get(key(sender, msg)); if (c) c.abort(); return; }
});

const key = (sender, m) => [sender.tab && sender.tab.id, sender.frameId, m.sid, m.rid].join(':');
const HDR_MARK = 'x-um-';
const FORBIDDEN = /^(referer|origin|user-agent|cookie|host|accept-encoding|connection|sec-fetch-.*|sec-.*)$/i;

function b64(buf) {
  const u = new Uint8Array(buf); let s = '';
  for (let i = 0; i < u.length; i += 8192) s += String.fromCharCode.apply(null, u.subarray(i, i + 8192));
  return btoa(s);
}

async function runXhr(msg, sender) {
  const d = msg.det, ctl = new AbortController(), k = key(sender, msg);
  xhrs.set(k, ctl);
  let timedOut = false, timer = 0;
  if (d.timeout) timer = setTimeout(() => { timedOut = true; ctl.abort(); }, d.timeout);
  try {
    const headers = {};
    for (const n in d.headers || {}) headers[FORBIDDEN.test(n) ? HDR_MARK + n : n] = String(d.headers[n]);
    const init = { method: d.method.toUpperCase(), headers, signal: ctl.signal, credentials: d.anonymous ? 'omit' : 'include', redirect: 'follow', cache: 'no-store' };
    if (init.method !== 'GET' && init.method !== 'HEAD') {
      if (d.form) { const f = new FormData(); d.form.forEach(([a, b]) => f.append(a, b)); init.body = f; }
      else if (d.b64) { const bin = atob(d.b64), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); init.body = u; }
      else if (d.data != null) init.body = d.data;
    }
    if (d.user) headers.Authorization = 'Basic ' + btoa(d.user + ':' + (d.password || ''));
    const r = await fetch(d.url, init);
    if (r.status >= 400) logEntry({ level: 'warn', sid: msg.sid, name: (scripts[msg.sid] || { meta: {} }).meta.name, msg: 'GM_xmlhttpRequest ' + init.method + ' ' + new URL(d.url).hostname + ' → HTTP ' + r.status });
    const buf = await r.arrayBuffer();
    const ctype = r.headers.get('content-type') || '';
    let hs = ''; r.headers.forEach((v, n) => { hs += n + ': ' + v + '\r\n'; });
    const out = { ev: 'load', status: r.status, statusText: r.statusText, headers: hs, finalUrl: r.url, ctype };
    if (d.responseType === 'arraybuffer' || d.responseType === 'blob') out.b64 = b64(buf);
    else out.text = new TextDecoder('utf-8').decode(buf);
    return out;
  } catch (e) {
    logEntry({ level: 'error', sid: msg.sid, name: (scripts[msg.sid] || { meta: {} }).meta.name, msg: 'GM_xmlhttpRequest ' + d.method + ' ' + String(d.url).slice(0, 60) + ' → ' + (timedOut ? 'timeout' : String(e.message || e)) });
    return { ev: timedOut ? 'timeout' : (e.name === 'AbortError' ? 'abort' : 'error'), status: 0, statusText: String(e.message || e), headers: '', finalUrl: d.url, text: '' };
  } finally { clearTimeout(timer); xhrs.delete(k); }
}

// ---------- header rewriting for extension fetches ----------
chrome.webRequest.onBeforeSendHeaders.addListener(d => {
  if (d.tabId !== -1) return;
  let hit = false;
  const h = [];
  const real = {};
  d.requestHeaders.forEach(x => { if (x.name.toLowerCase().startsWith(HDR_MARK)) { hit = true; real[x.name.slice(HDR_MARK.length).toLowerCase()] = x.value; } });
  if (!hit) return;
  d.requestHeaders.forEach(x => { const n = x.name.toLowerCase(); if (!n.startsWith(HDR_MARK) && !(n in real)) h.push(x); });
  for (const n in real) h.push({ name: n, value: real[n] });
  return { requestHeaders: h };
}, { urls: ['<all_urls>'] }, ['blocking', 'requestHeaders', 'extraHeaders']);

// ---------- remember frames that are Cloudflare checks (they send a "cf-mitigated" header): no scripts get injected there ----------
chrome.webRequest.onHeadersReceived.addListener(d => {
  const k = d.tabId + ':' + d.frameId;
  if (cfFrame(d)) cfFrames[k] = Date.now(); else delete cfFrames[k];
}, { urls: ['http://*/*', 'https://*/*'], types: ['main_frame', 'sub_frame'] }, ['responseHeaders']);

// ---------- strip CSP only on pages where a script will run ----------
chrome.webRequest.onHeadersReceived.addListener(d => {
  if (!settings.stripCsp || !settings.enabled) return;
  if (cfFrame(d)) return;
  if (!scriptsFor(d.url, d.type === 'main_frame').length) return;
  const h = d.responseHeaders.filter(x => !/^content-security-policy(-report-only)?$/i.test(x.name));
  if (h.length === d.responseHeaders.length) return;
  return { responseHeaders: h };
}, { urls: ['<all_urls>'], types: ['main_frame', 'sub_frame'] }, ['blocking', 'responseHeaders']);

// ---------- open .user.js links in install page ----------
chrome.webRequest.onBeforeRequest.addListener(d => {
  if (d.method !== 'GET' || !/\.user\.js([?#].*)?$/i.test(d.url)) return;
  return { redirectUrl: chrome.runtime.getURL('install.html') + '?url=' + encodeURIComponent(d.url) };
}, { urls: ['<all_urls>'], types: ['main_frame'] }, ['blocking']);

// ---------- IP-logger / grabber domain protection (from SiteDrift's list) ----------
chrome.webRequest.onBeforeRequest.addListener(d => {
  if (!settings.blockIpLoggers || d.method !== 'GET') return;
  let h; try { h = new URL(d.url).hostname.toLowerCase(); } catch (e) { return; }
  if (!IP_LOGGERS.some(x => h === x || h.endsWith('.' + x))) return;
  if ((allowed.get(h) || 0) > Date.now()) return;
  return { redirectUrl: chrome.runtime.getURL('blocked.html') + '?url=' + encodeURIComponent(d.url) };
}, { urls: ['<all_urls>'], types: ['main_frame'] }, ['blocking']);
window.api.allowHost = (h, mins = 10) => allowed.set(h, Date.now() + mins * 60000);

// ---------- network ad/tracker blocking (third-party only, never main pages, never extension requests) ----------
const tabHost = {}, tabCount = {}, badgeTimers = {};
const baseDom = h => h.split('.').slice(-2).join('.');
const NEVER = new Set(['cloudflare.com', 'challenges.cloudflare.com', 'cdnjs.cloudflare.com', 'cloudflare-dns.com', 'hcaptcha.com', 'recaptcha.net', 'gstatic.com']);
const neverHost = p => { for (let i = 0; i < p.length - 1; i++) if (NEVER.has(p.slice(i).join('.'))) return true; return false; };
function isAdHost(h) {
  const p = h.split('.');
  if (neverHost(p)) return false;
  if (popBlocked(h)) return true;
  for (let i = 0; i < p.length - 1; i++) if (adSet.has(p.slice(i).join('.'))) return true;
  return false;
}
function isPopupHost(h) {
  const p = h.split('.');
  if (neverHost(p)) return false;
  for (let i = 0; i < p.length - 1; i++) if (popupSet.has(p.slice(i).join('.'))) return true;
  return false;
}
chrome.webRequest.onBeforeRequest.addListener(d => { try { prevHost[d.tabId] = tabHost[d.tabId]; tabHost[d.tabId] = new URL(d.url).hostname.replace(/^www\./, ''); tabCount[d.tabId] = 0; chrome.browserAction.setBadgeText({ tabId: d.tabId, text: '' }); } catch (e) {} }, { urls: ['http://*/*', 'https://*/*'], types: ['main_frame'] });
chrome.webRequest.onBeforeRequest.addListener(d => {
  if (d.tabId < 0 || !settings.blockAds || !settings.enabled) return;
  let h; try { h = new URL(d.url).hostname.toLowerCase(); } catch (e) { return; }
  if (!isAdHost(h)) return;
  const top = tabHost[d.tabId];
  if (top) {
    if (baseDom(top) === baseDom(h)) return;
    if (settings.adWhitelist.includes(top)) return;
  }
  tabCount[d.tabId] = (tabCount[d.tabId] || 0) + 1;
  settings.adTotal++;
  if (settings.adTotal % 25 === 0) sset({ settings });
  clearTimeout(badgeTimers[d.tabId]);
  badgeTimers[d.tabId] = setTimeout(() => { try { chrome.browserAction.setBadgeBackgroundColor({ color: '#14b878' }); chrome.browserAction.setBadgeText({ tabId: d.tabId, text: String(tabCount[d.tabId]) }); } catch (e) {} }, 400);
  return neutral(d.type);
}, { urls: ['http://*/*', 'https://*/*'], types: ['sub_frame', 'script', 'image', 'xmlhttprequest', 'ping', 'stylesheet', 'media', 'object', 'other', 'font'] }, ['blocking']);
// Instead of failing the request, answer with an empty/harmless resource so anti-adblock "did the ad load?" checks pass.
const GIF = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
function neutral(type) {
  switch (type) {
    case 'script': return { redirectUrl: chrome.runtime.getURL('neutral.js') };
    case 'image': return { redirectUrl: GIF };
    case 'stylesheet': return { redirectUrl: 'data:text/css,' };
    case 'sub_frame': return { redirectUrl: 'data:text/html,%3C!doctype%20html%3E%3Ctitle%3E%3C/title%3E' };
    case 'xmlhttprequest': case 'other': return { redirectUrl: 'data:application/json,%7B%7D' };
    default: return { cancel: true };
  }
}
chrome.tabs.onRemoved.addListener(id => { delete tabHost[id]; delete tabCount[id]; });
window.api.adInfo = tabId => ({ host: tabHost[tabId] || '', count: tabCount[tabId] || 0, site: !settings.adWhitelist.includes(tabHost[tabId]), global: settings.blockAds, total: settings.adTotal });
window.api.setAdSite = async (host, on) => {
  const w = new Set(settings.adWhitelist); if (on) w.delete(host); else w.add(host);
  settings.adWhitelist = [...w]; await sset({ settings });
};


// ---------- permanent pop-up block: hosts you banned. Tabs they open are closed, navigations to them are cancelled ----------
const recentPops = [];   // hosts that opened in a tab created by another tab (newest first)
function popBlocked(h) { return (settings.popupBlock || []).some(x => h === x || h.endsWith('.' + x)); }
function notePop(h, url) { const i = recentPops.findIndex(r => r.host === h); if (i > -1) recentPops.splice(i, 1); recentPops.unshift({ host: h, url: String(url).slice(0, 120), t: Date.now() }); if (recentPops.length > 25) recentPops.pop(); }
Object.assign(window.api, {
  getPopupBlock: () => (settings.popupBlock || []).slice(),
  getRecentPops: () => recentPops.filter(r => !popBlocked(r.host)),
  async addPopupBlock(host) { host = String(host || '').toLowerCase().replace(/^www\./, '').trim(); if (!host || !host.includes('.')) return; const w = new Set(settings.popupBlock || []); w.add(host); settings.popupBlock = [...w]; await sset({ settings }); },
  async removePopupBlock(host) { settings.popupBlock = (settings.popupBlock || []).filter(x => x !== host); await sset({ settings }); }
});
chrome.webRequest.onBeforeRequest.addListener(d => {
  if (!settings.enabled || d.tabId < 0 || d.method !== 'GET') return;
  let h; try { h = new URL(d.url).hostname.toLowerCase().replace(/^www\./, ''); } catch (e) { return; }
  const blocked = popBlocked(h);
  const fresh = !prevHost[d.tabId];
  // learn: which sites open in tabs spawned by another tab (so you can ban them with one tap later)
  if (blocked || fresh) chrome.tabs.get(d.tabId, t => {
    if (chrome.runtime.lastError || !t) return;
    const popup = t.openerTabId != null || fresh;
    if (blocked) { if (popup) chrome.tabs.remove(d.tabId, () => void chrome.runtime.lastError); }
    else if (t.openerTabId != null) notePop(h, d.url);
  });
  if (blocked) { logEntry({ level: 'info', name: 'Pop-up block', msg: 'cancelled ' + h, host: prevHost[d.tabId] || '' }); return { cancel: true }; }
}, { urls: ['http://*/*', 'https://*/*'], types: ['main_frame'] }, ['blocking']);

// ---------- redirect guard: stop navigations to ad/pop-up networks (or, in strict mode, any tap-less cross-site redirect) ----------
chrome.webRequest.onBeforeRequest.addListener(d => {
  if (!settings.enabled || settings.redirectGuard === 'off' || d.method !== 'GET' || d.tabId < 0) return;
  let u; try { u = new URL(d.url); } catch (e) { return; }
  const h = u.hostname.toLowerCase().replace(/^www\./, '');
  if ((allowed.get(h) || 0) > Date.now() || (settings.redirectAllow || []).includes(h)) return;
  const from = prevHost[d.tabId] || '';
  let reason = '';
  if (isAdHost(h) || isPopupHost(h)) reason = 'known ad / pop-up network';
  else if (settings.redirectGuard === 'strict' && from && baseDom(from) !== baseDom(h) && Date.now() - (lastGesture[d.tabId] || 0) > 2500) reason = 'automatic redirect (you did not tap)';
  if (!reason) return;
  logEntry({ level: 'info', name: 'Redirect guard', msg: 'held ' + h + ' — ' + reason, host: from });
  return { redirectUrl: chrome.runtime.getURL('blocked.html') + '?kind=redirect&reason=' + encodeURIComponent(reason) + '&from=' + encodeURIComponent(from) + '&url=' + encodeURIComponent(d.url) };
}, { urls: ['http://*/*', 'https://*/*'], types: ['main_frame'] }, ['blocking']);
