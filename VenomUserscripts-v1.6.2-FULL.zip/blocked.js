const q = new URLSearchParams(location.search), url = q.get('url') || '', kind = q.get('kind') || 'ip';
let host = ''; try { host = new URL(url).hostname.replace(/^www\./, '').toLowerCase(); } catch (e) {}
const $ = id => document.getElementById(id);
$('h').textContent = kind === 'redirect' ? 'Redirect held' : 'Blocked: IP logger / grabber site';
$('why').textContent = kind === 'redirect' ? 'A page tried to send you to ' + host + ' — ' + (q.get('reason') || 'unknown reason') + '.' : 'This domain is on the known IP-logger list. Opening it would reveal your IP address to whoever made the link.';
$('u').textContent = url;
if (kind === 'redirect') $('always').hidden = false;
$('back').onclick = () => history.length > 1 ? history.back() : window.close();
$('go').onclick = () => chrome.runtime.getBackgroundPage(bg => { bg.api.allowHost(host, 10); location.replace(url); });
$('always').onclick = () => chrome.runtime.getBackgroundPage(async bg => { await bg.api.setRedirectAllow(host, true); location.replace(url); });
