(function () {
  'use strict';
  if (window.__umLoaded) return; window.__umLoaded = true;
  const NAMES = ['unsafeWindow', 'GM_info', 'GM', 'GM_getValue', 'GM_setValue', 'GM_deleteValue', 'GM_listValues', 'GM_addValueChangeListener', 'GM_removeValueChangeListener', 'GM_addStyle', 'GM_openInTab', 'GM_setClipboard', 'GM_xmlhttpRequest', 'GM_log', 'GM_registerMenuCommand', 'GM_unregisterMenuCommand', 'GM_getResourceText', 'GM_getResourceURL', 'GM_download', 'GM_notification', 'GM_addElement', 'GM_getValues', 'GM_setValues', 'GM_deleteValues', 'GM_getTab', 'GM_saveTab', 'GM_getTabs'];
  const menu = [];
  const msg = (m, cb) => { try { chrome.runtime.sendMessage(m, cb); } catch (e) {} };

  // Runs inside the PAGE world (stringified). Builds GM_* API and calls the userscript.
  function __umBootstrap(cfg, userFn) {
    var ch = cfg.ch, seq = 0, cbs = {}, vals = cfg.values || {}, vl = {}, vlid = 0, cmds = {}, cid = 0;
    var g = cfg.grants || [], none = !g.length || g.indexOf('none') > -1;
    function has(n) { return !none && g.indexOf(n) > -1; }
    function send(type, data, cb) {
      var rid = ++seq; if (cb) cbs[rid] = cb;
      document.dispatchEvent(new CustomEvent(ch + 'q', { detail: JSON.stringify({ rid: rid, type: type, data: data }) }));
      return rid;
    }
    document.addEventListener(ch + 'r', function (e) {
      var m; try { m = JSON.parse(e.detail); } catch (_) { return; }
      var cb = cbs[m.rid]; if (cb) { delete cbs[m.rid]; cb(m.data); }
    });
    document.addEventListener(ch + 'c', function (e) { var c = cmds[e.detail]; if (c) try { c.fn(); } catch (err) { console.error(err); } });
    function fire(k, o, n) { for (var i in vl) if (vl[i].k === k) try { vl[i].cb(k, o, n, false); } catch (e) { console.error(e); } }
    function b64(buf) {
      var u = buf instanceof ArrayBuffer ? new Uint8Array(buf) : new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength), s = '', i;
      for (i = 0; i < u.length; i += 8192) s += String.fromCharCode.apply(null, u.subarray(i, i + 8192));
      return btoa(s);
    }
    var api = { unsafeWindow: window };
    api.GM_info = { script: cfg.info, scriptHandler: 'Tampermonkey', version: '5.3.3', scriptMetaStr: '', isIncognito: false };
    api.GM_getValue = function (k, d) { return k in vals ? vals[k] : d; };
    api.GM_setValue = function (k, v) { var o = vals[k]; vals[k] = v; send('setValue', { k: k, v: v }); fire(k, o, v); };
    api.GM_deleteValue = function (k) { var o = vals[k]; delete vals[k]; send('delValue', { k: k }); fire(k, o, undefined); };
    api.GM_listValues = function () { return Object.keys(vals); };
    api.GM_addValueChangeListener = function (k, cb) { vl[++vlid] = { k: k, cb: cb }; return vlid; };
    api.GM_removeValueChangeListener = function (i) { delete vl[i]; };
    api.GM_addStyle = function (css) {
      var s = document.createElement('style'); s.textContent = css;
      var add = function () { (document.head || document.documentElement).appendChild(s); };
      if (document.head || document.documentElement) add(); else document.addEventListener('DOMContentLoaded', add);
      return s;
    };
    api.GM_openInTab = function (url, o) { send('openInTab', { url: new URL(url, location.href).href, opts: o }); return { close: function () {}, closed: false }; };
    api.GM_setClipboard = function (t) {
      t = String(t);
      var fb = function () { var a = document.createElement('textarea'); a.value = t; a.style.cssText = 'position:fixed;top:0;opacity:0'; (document.body || document.documentElement).appendChild(a); a.select(); try { document.execCommand('copy'); } catch (e) {} a.remove(); };
      try { navigator.clipboard.writeText(t).catch(fb); } catch (e) { fb(); }
    };
    api.GM_log = function () { console.log.apply(console, arguments); };
    api.GM_registerMenuCommand = function (name, fn) { var id = ++cid; cmds[id] = { fn: fn }; send('menuAdd', { cmdId: id, name: name }); return id; };
    api.GM_unregisterMenuCommand = function (id) { delete cmds[id]; send('menuDel', { cmdId: id }); };
    api.GM_xmlhttpRequest = function (d) {
      var det = { method: d.method || 'GET', url: new URL(String(d.url), location.href).href, headers: d.headers || {}, timeout: d.timeout || 0, responseType: d.responseType || '', anonymous: !!d.anonymous, user: d.user, password: d.password };
      var x = d.data;
      if (x != null) {
        if (typeof x === 'string') det.data = x;
        else if (x instanceof URLSearchParams) det.data = x.toString();
        else if (typeof FormData !== 'undefined' && x instanceof FormData) { var o = []; x.forEach(function (v, k) { if (typeof v === 'string') o.push([k, v]); }); det.form = o; }
        else if (x instanceof ArrayBuffer || ArrayBuffer.isView(x)) det.b64 = b64(x);
        else det.data = String(x);
      }
      var rid = send('xhr', det, function (r) {
        var rt = det.responseType, ct = r.ctype || '';
        var resp = { readyState: 4, status: r.status, statusText: r.statusText, responseHeaders: r.headers, finalUrl: r.finalUrl, context: d.context };
        if (rt === 'arraybuffer' || rt === 'blob') {
          var bin = atob(r.b64 || ''), u = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
          resp.response = rt === 'blob' ? new Blob([u], { type: ct }) : u.buffer; resp.responseText = '';
        } else {
          resp.responseText = r.text || '';
          if (rt === 'json') { try { resp.response = JSON.parse(resp.responseText); } catch (e) { resp.response = null; } }
          else resp.response = resp.responseText;
          if (rt === 'document' || /xml|html/.test(ct)) { try { resp.responseXML = new DOMParser().parseFromString(resp.responseText, /xml/.test(ct) && !/html/.test(ct) ? 'text/xml' : 'text/html'); if (rt === 'document') resp.response = resp.responseXML; } catch (e) {} }
        }
        try { d.onreadystatechange && d.onreadystatechange(resp); } catch (e) { console.error(e); }
        var h = { load: d.onload, error: d.onerror, timeout: d.ontimeout, abort: d.onabort }[r.ev];
        try { h && h(resp); } catch (e) { console.error(e); }
        try { d.onloadend && d.onloadend(resp); } catch (e) { console.error(e); }
      });
      return { abort: function () { send('xhrAbort', { target: rid }); } };
    };
    var RES = cfg.resources || {};
    api.GM_getResourceText = function (n) { return RES[n] && RES[n].text != null ? RES[n].text : ''; };
    api.GM_getResourceURL = function (n) { return RES[n] ? (RES[n].data || RES[n].url) : ''; };
    api.GM_getValues = function (k) { var o = {}; if (Array.isArray(k)) k.forEach(function (x) { o[x] = vals[x]; }); else for (var x in (k || {})) o[x] = x in vals ? vals[x] : k[x]; return o; };
    api.GM_setValues = function (o) { for (var k in o) api.GM_setValue(k, o[k]); };
    api.GM_deleteValues = function (a) { (a || []).forEach(function (k) { api.GM_deleteValue(k); }); };
    api.GM_addElement = function (a, b, c2) {
      var parent = typeof a === 'string' ? (document.head || document.documentElement) : a, tag = typeof a === 'string' ? a : b, at = typeof a === 'string' ? b : c2;
      var el = document.createElement(tag); for (var k in (at || {})) { if (k === 'textContent') el.textContent = at[k]; else el.setAttribute(k, at[k]); }
      (parent || document.documentElement).appendChild(el); return el;
    };
    api.GM_download = function (a, b) {
      var o = typeof a === 'string' ? { url: a, name: b } : a;
      return api.GM_xmlhttpRequest({ url: o.url, headers: o.headers, responseType: 'blob', onerror: o.onerror, ontimeout: o.ontimeout,
        onload: function (r) { var u = URL.createObjectURL(r.response), l = document.createElement('a'); l.href = u; l.download = o.name || 'download'; (document.body || document.documentElement).appendChild(l); l.click(); setTimeout(function () { l.remove(); URL.revokeObjectURL(u); }, 1500); if (o.onload) o.onload(r); } });
    };
    api.GM_notification = function (a, b, c2, d) {
      var o = typeof a === 'object' ? a : { text: a, title: b, image: c2, onclick: d };
      try {
        var show = function () { var n = new Notification(o.title || cfg.info.name, { body: o.text, icon: o.image }); if (o.onclick) n.onclick = o.onclick; if (o.timeout) setTimeout(function () { n.close(); }, o.timeout); };
        if (window.Notification && Notification.permission === 'granted') show();
        else if (window.Notification && Notification.permission !== 'denied') Notification.requestPermission().then(function (p) { if (p === 'granted') show(); });
        else console.log('[' + cfg.info.name + '] ' + (o.title || '') + ' ' + o.text);
      } catch (e) {}
    };
    var tabKey = '__um_tab_' + cfg.id;
    api.GM_saveTab = function (o) { try { sessionStorage.setItem(tabKey, JSON.stringify(o)); } catch (e) {} };
    api.GM_getTab = function (cb) { var v = {}; try { v = JSON.parse(sessionStorage.getItem(tabKey) || '{}'); } catch (e) {} cb(v); };
    api.GM_getTabs = function (cb) { api.GM_getTab(function (v) { cb({ 0: v }); }); };
    var GM = {};
    GM.info = api.GM_info;
    GM.getValue = function (k, d) { return Promise.resolve(api.GM_getValue(k, d)); };
    GM.setValue = function (k, v) { api.GM_setValue(k, v); return Promise.resolve(); };
    GM.deleteValue = function (k) { api.GM_deleteValue(k); return Promise.resolve(); };
    GM.listValues = function () { return Promise.resolve(api.GM_listValues()); };
    GM.addStyle = function (c) { return Promise.resolve(api.GM_addStyle(c)); };
    GM.openInTab = function (u, o) { return Promise.resolve(api.GM_openInTab(u, o)); };
    GM.setClipboard = function (t) { api.GM_setClipboard(t); return Promise.resolve(); };
    GM.registerMenuCommand = function (n, f) { return Promise.resolve(api.GM_registerMenuCommand(n, f)); };
    GM.xmlHttpRequest = function (d) {
      return new Promise(function (res, rej) {
        var o = Object.assign({}, d), l = d.onload, e = d.onerror, t = d.ontimeout;
        o.onload = function (r) { l && l(r); res(r); };
        o.onerror = function (r) { e && e(r); rej(r); };
        o.ontimeout = function (r) { t && t(r); rej(r); };
        api.GM_xmlhttpRequest(o);
      });
    };
    GM.getResourceText = function (n) { return Promise.resolve(api.GM_getResourceText(n)); };
    GM.getResourceUrl = GM.getResourceURL = function (n) { return Promise.resolve(api.GM_getResourceURL(n)); };
    GM.download = function (a, b) { return new Promise(function (res, rej) { var o = typeof a === 'string' ? { url: a, name: b } : Object.assign({}, a); o.onload = res; o.onerror = rej; o.ontimeout = rej; api.GM_download(o); }); };
    GM.notification = function (a, b, c2, d) { api.GM_notification(a, b, c2, d); return Promise.resolve(); };
    GM.addElement = function (a, b, c2) { return Promise.resolve(api.GM_addElement(a, b, c2)); };
    GM.getValues = function (k) { return Promise.resolve(api.GM_getValues(k)); };
    GM.setValues = function (o) { api.GM_setValues(o); return Promise.resolve(); };
    GM.deleteValues = function (a) { api.GM_deleteValues(a); return Promise.resolve(); };
    GM.getTab = function () { return new Promise(function (r) { api.GM_getTab(r); }); };
    GM.saveTab = function (o) { api.GM_saveTab(o); return Promise.resolve(); };
    GM.getTabs = function () { return new Promise(function (r) { api.GM_getTabs(r); }); };
    api.GM = GM;
    // error console: report uncaught errors raised by this script, and how long its start-up took
    var srcName = 'userscript-' + encodeURIComponent(cfg.info.name);
    var rep = function (level, msg) { send('log', { level: level, msg: String(msg).slice(0, 300) }); };
    window.addEventListener('error', function (e) { if (e.filename && e.filename.indexOf(srcName) > -1) rep('error', (e.message || 'error') + ' (line ' + e.lineno + ')'); });
    window.addEventListener('unhandledrejection', function (e) { var s = e.reason && e.reason.stack; if (s && String(s).indexOf(srcName) > -1) rep('error', 'Unhandled promise: ' + (e.reason.message || e.reason)); });
    if (g.indexOf('window.onurlchange') > -1 && !window.__umUrl) {
      window.__umUrl = true; if (!('onurlchange' in window)) window.onurlchange = null;
      var last = location.href, fire2 = function () { var n = location.href; if (n === last) return; var ev = new Event('urlchange'); ev.url = n; ev.from = last; ev.to = n; last = n; try { if (typeof window.onurlchange === 'function') window.onurlchange(ev); } catch (e) {} window.dispatchEvent(ev); };
      ['pushState', 'replaceState'].forEach(function (k) { var o = history[k]; history[k] = function () { var r = o.apply(this, arguments); setTimeout(fire2, 0); return r; }; });
      window.addEventListener('popstate', fire2); window.addEventListener('hashchange', fire2);
    }
    var out = cfg.names.map(function (n) {
      if (n === 'unsafeWindow') return window;
      if (n === 'GM_info') return none ? undefined : api.GM_info;
      if (n === 'GM') {
        if (none) return undefined;
        var o = {}, any = false; for (var k in GM) if (k === 'info' || has('GM.' + k)) { o[k] = GM[k]; any = true; }
        return any ? o : undefined;
      }
      return has(n) || (n === 'GM_xmlhttpRequest' && has('GM_xmlHttpRequest')) ? api[n] : undefined;
    });
    var t0 = performance.now();
    try { userFn.apply(window, out); } catch (e) { console.error('[Userscripts] ' + cfg.info.name + ':', e); rep('error', (e && e.message) || e); }
    send('log', { kind: 'run', ms: performance.now() - t0 });
  }

  function listen(ch, sc) {
    document.addEventListener(ch + 'q', e => {
      let m; try { m = JSON.parse(e.detail); } catch (_) { return; }
      const reply = data => document.dispatchEvent(new CustomEvent(ch + 'r', { detail: JSON.stringify({ rid: m.rid, data }) }));
      switch (m.type) {
        case 'log': msg({ type: 'log', sid: sc.id, kind: m.data.kind, level: m.data.level, msg: m.data.msg, ms: m.data.ms, host: location.hostname }); break;
        case 'setValue': msg({ type: 'setValue', id: sc.id, k: m.data.k, v: m.data.v }); break;
        case 'delValue': msg({ type: 'delValue', id: sc.id, k: m.data.k }); break;
        case 'openInTab': msg({ type: 'openInTab', url: m.data.url, opts: m.data.opts }); break;
        case 'xhr': msg({ type: 'xhr', sid: sc.id, rid: m.rid, det: m.data }, r => reply(r || { ev: 'error', status: 0, statusText: 'No response from extension', text: '', headers: '', finalUrl: '' })); break;
        case 'xhrAbort': msg({ type: 'xhrAbort', sid: sc.id, rid: m.data.target }); break;
        case 'menuAdd': menu.push({ ch, sid: sc.id, sname: sc.name, cmdId: m.data.cmdId, name: m.data.name }); break;
        case 'menuDel': { const i = menu.findIndex(x => x.ch === ch && x.cmdId === m.data.cmdId); if (i > -1) menu.splice(i, 1); break; }
      }
    });
  }

  function inject(sc) {
    const parent = document.head || document.documentElement;
    if (!parent) { new MutationObserver((_, o) => { if (document.documentElement) { o.disconnect(); inject(sc); } }).observe(document, { childList: true }); return; }
    const ch = '__um' + Math.random().toString(36).slice(2);
    listen(ch, sc);
    const cfg = { ch, id: sc.id, names: NAMES, grants: sc.grants, values: sc.values, info: sc.info, resources: sc.resources };
    const text = '(' + __umBootstrap.toString() + ')(' + JSON.stringify(cfg) + ',function(' + NAMES.join(',') + '){\n' + sc.code + '\n});\n//# sourceURL=userscript-' + encodeURIComponent(sc.name) + '.js';
    const el = document.createElement('script');
    el.textContent = text;
    parent.appendChild(el); el.remove();
  }

  function schedule(sc) {
    const rs = document.readyState;
    switch (sc.runAt) {
      case 'document-start': inject(sc); break;
      case 'document-body':
        if (document.body) inject(sc);
        else new MutationObserver((_, o) => { if (document.body) { o.disconnect(); inject(sc); } }).observe(document.documentElement || document, { childList: true, subtree: true });
        break;
      default:
        if (rs !== 'loading') inject(sc); else document.addEventListener('DOMContentLoaded', () => inject(sc), { once: true });
    }
  }

  chrome.runtime.onMessage.addListener((m, s, send) => {
    if (m.type === 'getMenu') { send(menu.map(x => ({ ch: x.ch, sname: x.sname, cmdId: x.cmdId, name: x.name }))); }
    else if (m.type === 'runMenu') document.dispatchEvent(new CustomEvent(m.ch + 'c', { detail: String(m.cmdId) }));
  });

  msg({ type: 'getScripts', url: location.href }, r => {
    if (chrome.runtime.lastError || !r) return;
    if (r.guard && window === window.top) { let g = 0; ['touchend', 'click', 'keydown'].forEach(n => addEventListener(n, e => { if (e.isTrusted && Date.now() - g > 700) { g = Date.now(); msg({ type: 'gesture' }); } }, true)); }
    r.scripts.forEach(schedule);
  });
})();
