'use strict';
// Minimal network-filter parser: keeps only plain domain rules (||host^ and hosts-file lines). Everything else is ignored to stay light.
const OPT_OK = /^(third-party|3p|script|image|stylesheet|subdocument|xmlhttprequest|xhr|media|font|ping|other|important|all)$/;
function parseList(text) {
  const hosts = new Set(), popup = new Set();
  const re = /^\|\|([a-z0-9][a-z0-9.-]*[a-z0-9])\^?(\$.*)?$/i;
  const hostsLine = /^(?:0\.0\.0\.0|127\.0\.0\.1)\s+([a-z0-9][a-z0-9._-]*)\s*(?:#.*)?$/i;
  for (let line of text.split('\n')) {
    line = line.trim();
    if (!line || line[0] === '!' || line[0] === '#' || line[0] === '[' || line.startsWith('@@') || line.includes('##') || line.includes('#@#') || line.includes('#?#') || line.includes('#$#') || line.includes('+js(')) continue;
    let m = line.match(hostsLine);
    if (m) { if (m[1] !== 'localhost' && m[1].includes('.')) hosts.add(m[1].toLowerCase()); continue; }
    m = line.match(re);
    if (!m || !m[1].includes('.')) continue;
    const h = m[1].toLowerCase();
    if (!m[2]) { hosts.add(h); continue; }
    const opts = m[2].slice(1).split(',').map(s => s.trim());
    if (opts.some(o => o.startsWith('domain=') || o.startsWith('~') || o.startsWith('redirect') || o.startsWith('csp') || o.startsWith('removeparam') || o === 'badfilter')) continue;
    if (opts.includes('popup')) { popup.add(h); continue; }
    if (opts.every(o => OPT_OK.test(o))) hosts.add(h);
  }
  return { hosts: [...hosts], popup: [...popup] };
}
if (typeof module !== 'undefined') module.exports = { parseList };
