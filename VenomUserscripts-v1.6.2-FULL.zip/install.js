const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const url = new URLSearchParams(location.search).get('url');
chrome.runtime.getBackgroundPage(async bg => {
  try {
    const { code, meta } = await bg.api.preview(url);
    const g = meta.grant.filter(x => x !== 'none');
    const rules = meta.match.concat(meta.include);
    $('box').innerHTML = `<div class="s-name">${esc(meta.name)} <span class="tag">v${esc(meta.version || '?')}</span></div>
      <div class="s-meta">${esc(meta.description || '')}</div>
      <p class="mut">Runs on: ${rules.slice(0, 6).map(esc).join('<br>') || 'nothing'}${rules.length > 6 ? '<br>…and ' + (rules.length - 6) + ' more' : ''}</p>
      <p class="mut">Permissions: ${g.map(esc).join(', ') || 'none'}${g.some(x => /xmlhttp/i.test(x)) ? '<br><b style="color:#e5a000">Can make cross-site requests</b>' : ''}</p>
      <p class="mut">Only install scripts you trust: they can read and change pages they run on.</p>
      <div class="row"><button id="ok">Install</button><button class="sec" id="no">Cancel</button><button class="sec" id="src">View source</button></div>
      <pre id="pre" hidden style="white-space:pre-wrap;word-break:break-all;font-size:11px;max-height:300px;overflow:auto"></pre>`;
    $('ok').onclick = async () => { try { $('ok').disabled = true; const s = await bg.api.install(code, { url, fresh: true }); $('box').innerHTML = '<b>Installed: ' + esc(s.meta.name) + '</b><div class="row" style="margin-top:10px"><button id="d">Dashboard</button></div>'; $('d').onclick = () => chrome.runtime.openOptionsPage(); } catch (e) { $('msg').textContent = 'Error: ' + e.message; $('msg').className = 'err'; $('msg').style.display = 'block'; $('ok').disabled = false; } };
    $('no').onclick = () => history.length > 1 ? history.back() : window.close();
    $('src').onclick = () => { $('pre').textContent = code.slice(0, 20000); $('pre').hidden = false; };
  } catch (e) { $('box').textContent = 'Could not load script: ' + e.message; }
});
