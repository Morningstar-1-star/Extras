'use strict';
function parseMeta(code) {
  const m = code.match(/\/\/\s*==UserScript==([\s\S]*?)\/\/\s*==\/UserScript==/);
  if (!m) return null;
  const meta = { name: '', namespace: '', version: '', description: '', author: '', match: [], include: [], exclude: [], excludeMatch: [], grant: [], require: [], resource: [], connect: [], runAt: '', noframes: false, updateURL: '', downloadURL: '' };
  m[1].split(/\r?\n/).forEach(line => {
    const r = line.match(/^\s*\/\/\s*@([\w:\-]+)(?:\s+(.*?))?\s*$/);
    if (!r) return;
    const k = r[1].toLowerCase(), v = (r[2] || '').trim();
    switch (k) {
      case 'name': meta.name = v; break;
      case 'namespace': meta.namespace = v; break;
      case 'version': meta.version = v; break;
      case 'description': meta.description = v; break;
      case 'author': meta.author = v; break;
      case 'match': if (v) meta.match.push(v); break;
      case 'include': if (v) meta.include.push(v); break;
      case 'exclude': if (v) meta.exclude.push(v); break;
      case 'exclude-match': if (v) meta.excludeMatch.push(v); break;
      case 'grant': if (v) meta.grant.push(v); break;
      case 'require': if (v) meta.require.push(v); break;
      case 'resource': if (v) meta.resource.push(v); break;
      case 'connect': if (v) meta.connect.push(v); break;
      case 'run-at': meta.runAt = v; break;
      case 'noframes': meta.noframes = true; break;
      case 'updateurl': meta.updateURL = v; break;
      case 'downloadurl': meta.downloadURL = v; break;
    }
  });
  return meta;
}

function cmpVersion(a, b) {
  const ta = String(a || '0').split(/[.\-+_]/), tb = String(b || '0').split(/[.\-+_]/);
  for (let i = 0; i < Math.max(ta.length, tb.length); i++) {
    const x = ta[i] === undefined ? '0' : ta[i], y = tb[i] === undefined ? '0' : tb[i];
    const nx = /^\d+$/.test(x), ny = /^\d+$/.test(y);
    if (nx && ny) { if (+x !== +y) return +x > +y ? 1 : -1; }
    else if (x !== y) return x > y ? 1 : -1;
  }
  return 0;
}

const esc = s => s.replace(/[.+^${}()|[\]\\?]/g, '\\$&');

function matchPat(p) {
  if (p === '<all_urls>') return u => /^(https?|file|ftp):/.test(u);
  const m = p.match(/^(\*|https?|file|ftp):\/\/([^/]*)(\/.*)$/);
  if (!m) return null;
  const sch = m[1], host = m[2].replace(/:\d+$/, '').toLowerCase();
  const pre = new RegExp('^' + esc(m[3]).replace(/\*/g, '.*') + '$');
  const hostRe = host.includes('*') && !host.startsWith('*.') ? new RegExp('^' + esc(host).replace(/\*/g, '.*') + '$') : null;
  return urlStr => {
    let u; try { u = new URL(urlStr); } catch (e) { return false; }
    const s = u.protocol.slice(0, -1);
    if (sch === '*' ? !(s === 'http' || s === 'https') : s !== sch) return false;
    const h = u.hostname.toLowerCase();
    if (host !== '*') {
      if (hostRe) { if (!hostRe.test(h)) return false; }
      else if (host.startsWith('*.')) { const b = host.slice(2); if (!(h === b || h.endsWith('.' + b))) return false; }
      else if (h !== host) return false;
    }
    return pre.test(u.pathname + u.search);
  };
}

function incPat(p) {
  const rm = p.match(/^\/(.+)\/([gimsuy]*)$/);
  if (rm) { try { const re = new RegExp(rm[1], rm[2].replace(/[gy]/g, '')); return u => re.test(u); } catch (e) { return null; } }
  if (p === '*') return () => true;
  const re = new RegExp('^' + esc(p).replace(/\*/g, '.*') + '$', 'i');
  return u => re.test(u);
}

function compileRules(meta) {
  const inc = [], exc = [];
  meta.match.forEach(p => { const f = matchPat(p); if (f) inc.push(f); });
  meta.include.forEach(p => { const f = incPat(p); if (f) inc.push(f); });
  meta.exclude.forEach(p => { const f = incPat(p); if (f) exc.push(f); });
  meta.excludeMatch.forEach(p => { const f = matchPat(p); if (f) exc.push(f); });
  return { inc, exc };
}

if (typeof module !== 'undefined') module.exports = { parseMeta, cmpVersion, compileRules };
