/* Harmless stand-in for blocked ad scripts: anti-adblock checks see "ads loaded", nothing is shown. */
(function (w) {
  try {
    var noop = function () {}, self = function () { return proxy; };
    var proxy = new Proxy(function () {}, { get: function (t, k) { return k === 'then' ? undefined : self; }, apply: function () { return proxy; } });
    w.adsbygoogle = w.adsbygoogle || [];
    try { w.adsbygoogle.loaded = true; w.adsbygoogle.push = w.adsbygoogle.push || noop; } catch (e) {}
    w.canRunAds = true;
    w.googletag = w.googletag || { cmd: { push: function (f) { try { typeof f === 'function' && f(); } catch (e) {} } }, apiReady: true, pubads: self, defineSlot: self, defineOutOfPageSlot: self, enableServices: noop, display: noop, sizeMapping: self, destroySlots: noop };
    w.ga = w.ga || noop; w.gtag = w.gtag || noop; w.dataLayer = w.dataLayer || [];
    w._gaq = w._gaq || { push: noop };
    w.ezstandalone = w.ezstandalone || { cmd: [] };
  } catch (e) {}
})(window);
