let bg, editingId = null, filter = 'all', logLevel = 'all', tab = 'scripts';
const $ = id => document.getElementById(id);
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const ago = t => { if (!t) return 'never'; const m = Math.round((Date.now() - t) / 60000); return m < 60 ? m + ' min ago' : m < 1440 ? Math.round(m / 60) + ' h ago' : Math.round(m / 1440) + ' d ago'; };
function say(t, err) { const m = $('msg'); m.textContent = t; m.className = err ? 'err' : ''; m.style.display = 'block'; scrollTo(0, 0); }
async function guard(fn) { try { await fn(); } catch (e) { say('Error: ' + (e.message || e), true); } render(); }
function show(t) { tab = t; document.querySelectorAll('section').forEach(s => s.hidden = s.id !== 't-' + t); document.querySelectorAll('#nav button').forEach(b => b.classList.toggle('on', b.dataset.t === t)); render(); }
$('nav').onclick = e => { const b = e.target.closest('button'); if (b) { history.replaceState(null, '', '#' + b.dataset.t); show(b.dataset.t); } };

function renderScripts() {
  const q = $('q').value.toLowerCase(), st = bg.api.getStats();
  let all = bg.api.list();
  const list = all.filter(s => (!q || s.meta.name.toLowerCase().includes(q)) && (filter === 'all' || (filter === 'fav' && s.fav) || (filter === 'on' && s.enabled) || (filter === 'err' && ((st[s.id] || {}).errors || s.syntaxError)))).sort((a, b) => (b.fav ? 1 : 0) - (a.fav ? 1 : 0));
  $('count').textContent = list.length + '/' + all.length;
  $('list').innerHTML = list.map(s => { const x = st[s.id]; return `<div class="card" data-id="${s.id}">
    <div class="row sp"><button class="star ${s.fav ? 'on' : ''}" data-a="fav">★</button><div style="flex:1;min-width:0"><div class="s-name">${esc(s.meta.name)}</div>
    <div class="s-meta"><span class="tag">v${esc(s.meta.version || '?')}</span>${s.edited ? '<span class="tag">edited</span>' : ''}${s.syntaxError ? '<span class="tag" style="color:#e5484d" title="' + esc(s.syntaxError) + '">broken: syntax error</span>' : ''}${x && x.errors ? '<span class="tag" style="color:#e5484d">' + x.errors + ' errors</span>' : ''}${x ? '<span class="tag">' + x.runs + ' runs · avg ' + Math.round(x.ms / Math.max(1, x.runs)) + ' ms</span>' : ''}${(s.excl || []).length ? '<span class="tag">off on ' + s.excl.length + ' site(s)</span>' : ''}</div></div>
    <label class="sw"><input type="checkbox" data-a="tog" ${s.enabled ? 'checked' : ''}><i></i></label></div>
    <div class="row" style="margin-top:8px"><button class="sec" data-a="upd">Update</button><button class="sec" data-a="edit">Edit</button><button class="bad" data-a="del">Delete</button></div></div>`; }).join('') || '<div class="mut">Nothing here. Import your zip or paste a link.</div>';
}
function renderSites() {
  const h = $('host').value.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0];
  const st = bg.api.getSettings(), box = $('site');
  if (!h) box.innerHTML = '<div class="mut">Enter a site to control it: scripts, ad blocking and redirects.</div>';
  else {
    const sc = bg.api.siteScripts(h);
    box.innerHTML = `<div class="card"><div class="s-name">${esc(h)}</div>
      <label class="ck"><input type="checkbox" data-s="ads" ${st.adWhitelist.includes(h) ? '' : 'checked'}> Block ads here</label>
      <label class="ck"><input type="checkbox" data-s="redir" ${(st.redirectAllow || []).includes(h) ? 'checked' : ''}> Always allow redirects to this site</label></div>
      <h2>Scripts that run on ${esc(h)}</h2>` + (sc.map(s => `<div class="card row sp" data-id="${s.id}"><span class="s-name">${s.fav ? '★ ' : ''}${esc(s.name)}</span><label class="sw"><input type="checkbox" data-s="scr" ${s.enabled && !s.excluded ? 'checked' : ''}><i></i></label></div>`).join('') || '<div class="mut">No scripts match this site.</div>');
  }
  $('sitelist').innerHTML = bg.api.sites().map(x => `<div class="card row sp" data-h="${esc(x.host)}"><div><div class="s-name">${esc(x.host)}</div><div class="s-meta">${x.scripts.length ? 'scripts off: ' + esc(x.scripts.join(', ')) : ''}${x.ads ? ' · ads allowed' : ''}${x.redirect ? ' · redirects allowed' : ''}</div></div><button class="sec" data-a="open">Open</button></div>`).join('') || '<div class="mut">None yet.</div>';
}
function renderFilters() {
  const st = bg.api.getSettings();
  $('adinfo').textContent = bg.api.adSetSize().toLocaleString() + ' ad/tracker domains active · blocked so far: ' + (st.adTotal || 0).toLocaleString();
  $('lists').innerHTML = bg.api.getLists().map(L => `<div class="card row sp" data-id="${L.id}"><div style="flex:1;min-width:0"><div class="s-name">${esc(L.name)}</div><div class="s-meta">${L.count ? L.count.toLocaleString() + ' rules · updated ' + ago(L.updated) : (L.on ? 'downloading…' : 'off')}</div></div>${L.custom ? '<button class="bad" data-a="rm">×</button>' : ''}<label class="sw"><input type="checkbox" data-a="list" ${L.on ? 'checked' : ''}><i></i></label></div>`).join('');
  $('guard').value = st.redirectGuard || 'ads';
  $('allowed').textContent = (st.redirectAllow || []).length ? 'Always allowed: ' + st.redirectAllow.join(', ') : '';
}
function renderConsole() {
  const st = bg.api.getStats(), names = {}; bg.api.list().forEach(s => names[s.id] = s.meta.name);
  $('stats').innerHTML = '<tr><th>Script</th><th>Runs</th><th>Avg ms</th><th>Max</th><th>Err</th></tr>' + Object.keys(st).map(id => `<tr><td>${esc(names[id] || id)}</td><td>${st[id].runs}</td><td>${Math.round(st[id].ms / Math.max(1, st[id].runs))}</td><td>${Math.round(st[id].max)}</td><td>${st[id].errors}</td></tr>`).join('');
  $('log').innerHTML = bg.api.getLog().filter(e => logLevel === 'all' || e.level === logLevel).map(e => `<div class="lg"><b class="${e.level}">${esc(e.level)}</b> ${new Date(e.t).toLocaleTimeString()} · ${esc(e.name || '')}${e.host ? ' @ ' + esc(e.host) : ''}<br>${esc(e.msg)}</div>`).join('') || '<div class="mut">No errors or failed requests recorded.</div>';
}
function renderSettings() {
  const st = bg.api.getSettings();
  $('master').checked = st.enabled; $('csp').checked = st.stripCsp; $('cf').checked = st.cfSafe !== false; $('auto').checked = st.autoUpdate; $('blk').checked = st.blockIpLoggers; $('ads').checked = st.blockAds;
  $('hrs').value = String(st.updateHours); $('ldays').value = String(st.listDays || 3);
  $('adtot').textContent = 'Blocked so far: ' + (st.adTotal || 0).toLocaleString();
  $('last').textContent = st.lastUpdateRun ? 'Last script update check: ' + new Date(st.lastUpdateRun).toLocaleString() : '';
}
function render() { $('master').checked = bg.api.getSettings().enabled; ({ scripts: renderScripts, sites: renderSites, filters: renderFilters, console: renderConsole, settings: renderSettings })[tab](); }

$('list').addEventListener('click', e => {
  const b = e.target.closest('[data-a]'); if (!b) return;
  const id = b.closest('.card').dataset.id, s = bg.api.list().find(x => x.id === id);
  if (b.dataset.a === 'fav') return guard(() => bg.api.setFav(id, !s.fav));
  if (b.dataset.a === 'tog') return guard(() => bg.api.setEnabled(id, b.checked));
  if (b.dataset.a === 'del') { if (confirm('Delete "' + s.meta.name + '"?')) guard(() => bg.api.remove(id)); return; }
  if (b.dataset.a === 'edit') { editingId = id; $('edtitle').textContent = 'Editing: ' + s.meta.name; $('code').value = s.code; $('editor').hidden = false; scrollTo(0, 0); return; }
  if (b.dataset.a === 'upd') guard(async () => {
    b.disabled = true; let r = await bg.api.checkUpdate(id, false);
    if (r.status === 'edited' && confirm('This script was edited locally. Overwrite with the online version?')) r = await bg.api.checkUpdate(id, true);
    say({ updated: 'Updated ' + (r.from || '') + ' → ' + r.to, uptodate: 'Already up to date (v' + r.version + ')', nourl: 'No update URL in this script', edited: 'Skipped (edited)', error: 'Update failed: ' + r.error }[r.status] || r.status, r.status === 'error');
  });
});
document.querySelectorAll('.chip[data-f]').forEach(c => c.onclick = () => { filter = c.dataset.f; document.querySelectorAll('.chip[data-f]').forEach(x => x.classList.toggle('on', x === c)); render(); });
document.querySelectorAll('.chip[data-l]').forEach(c => c.onclick = () => { logLevel = c.dataset.l; document.querySelectorAll('.chip[data-l]').forEach(x => x.classList.toggle('on', x === c)); render(); });
$('q').oninput = render;
$('loadsite').onclick = render; $('host').onkeydown = e => { if (e.key === 'Enter') render(); };
$('site').onchange = e => { const t = e.target, k = t.dataset.s; if (!k) return; const h = $('host').value.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0];
  guard(async () => { if (k === 'ads') await bg.api.setAdSite(h, t.checked); else if (k === 'redir') await bg.api.setRedirectAllow(h, t.checked); else { const id = t.closest('.card').dataset.id; await bg.api.setSiteExcluded(id, h, !t.checked); if (t.checked) await bg.api.setEnabled(id, true); } }); };
$('sitelist').onclick = e => { const b = e.target.closest('[data-a=open]'); if (b) { $('host').value = b.closest('.card').dataset.h; render(); scrollTo(0, 0); } };
$('lists').onchange = e => { const t = e.target; if (t.dataset.a === 'list') guard(() => bg.api.setList(t.closest('.card').dataset.id, t.checked)); };
$('lists').onclick = e => { const b = e.target.closest('[data-a=rm]'); if (b && confirm('Remove this list?')) guard(() => bg.api.removeList(b.closest('.card').dataset.id)); };
$('updlists').onclick = () => guard(async () => { say('Updating lists…'); const r = await bg.api.updateLists(true); say('Lists updated: ' + r.ok + ' ok, ' + r.fail + ' failed' + (r.fail ? ' (see Console)' : '')); });
$('addlist').onclick = () => guard(async () => { const u = $('listurl').value.trim(); if (!/^https?:\/\//.test(u)) throw new Error('Enter a full http(s) link'); say('Downloading…'); await bg.api.addList(u); $('listurl').value = ''; say('List added'); });
$('guard').onchange = e => guard(() => bg.api.setSettings({ redirectGuard: e.target.value }));
$('reload').onclick = render; $('clearlog').onclick = () => { bg.api.clearLog(); render(); };
$('master').onchange = e => guard(() => bg.api.setSettings({ enabled: e.target.checked }));
$('cf').onchange = e => guard(() => bg.api.setSettings({ cfSafe: e.target.checked }));
$('csp').onchange = e => guard(() => bg.api.setSettings({ stripCsp: e.target.checked }));
$('ads').onchange = e => guard(() => bg.api.setSettings({ blockAds: e.target.checked }));
$('blk').onchange = e => guard(() => bg.api.setSettings({ blockIpLoggers: e.target.checked }));
$('auto').onchange = e => guard(() => bg.api.setSettings({ autoUpdate: e.target.checked }));
$('hrs').onchange = e => guard(() => bg.api.setSettings({ updateHours: +e.target.value }));
$('ldays').onchange = e => guard(() => bg.api.setSettings({ listDays: +e.target.value }));
$('inst').onclick = () => guard(async () => { const u = $('url').value.trim(); if (!u) return; $('inst').disabled = true; try { const s = await bg.api.installFromUrl(u); $('url').value = ''; say('Installed: ' + s.meta.name + ' v' + s.meta.version); } finally { $('inst').disabled = false; } });
$('zipbtn').onclick = () => $('file').click();
$('file').onchange = e => guard(async () => {
  const lines = [];
  for (const f of e.target.files) {
    if (/\.zip$/i.test(f.name)) { say('Importing ' + f.name + '…'); const r = await bg.api.importZip(await f.arrayBuffer()); lines.push('Imported ' + r.imported.length + ' from ' + f.name + (r.errors.length ? '\nErrors:\n' + r.errors.join('\n') : '')); }
    else { const s = await bg.api.install(await f.text(), { url: '' }); lines.push('Installed ' + s.meta.name); }
  }
  e.target.value = ''; say(lines.join('\n'));
});
$('newbtn').onclick = () => { editingId = null; $('edtitle').textContent = 'New script (paste full code with ==UserScript== header)'; $('code').value = '// ==UserScript==\n// @name        My Script\n// @match       *://*/*\n// @grant       none\n// ==/UserScript==\n\n'; $('editor').hidden = false; };
$('cancel').onclick = () => { $('editor').hidden = true; };
$('save').onclick = () => guard(async () => { const c = $('code').value; const s = editingId ? await bg.api.saveCode(editingId, c) : await bg.api.install(c, { edited: true }); editingId = s.id; say('Saved: ' + s.meta.name); });
$('updall').onclick = () => guard(async () => { say('Checking all scripts…'); const r = await bg.api.updateAll(); say('Updated ' + r.updated + ' · up to date ' + r.uptodate + ' · skipped ' + r.skipped + ' · errors ' + r.errors + (r.details.length ? '\n' + r.details.join('\n') : '')); });
$('clr').onclick = () => guard(async () => { say('Cleared ' + (await bg.api.clearRequireCache()) + ' cached libraries'); });

chrome.runtime.getBackgroundPage(async p => {
  bg = p; await bg.api.ready;
  const q = new URLSearchParams(location.search); if (q.get('host')) $('host').value = q.get('host');
  const h = (location.hash || '#scripts').slice(1);
  show(['scripts', 'sites', 'filters', 'console', 'settings'].includes(h) ? h : 'scripts');
});
