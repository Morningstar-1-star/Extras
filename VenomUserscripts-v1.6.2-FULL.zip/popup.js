const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
chrome.runtime.getBackgroundPage(async bg => {
  await bg.api.ready;
  $('master').checked = bg.api.getSettings().enabled;
  $('master').onchange = e => bg.api.setSettings({ enabled: e.target.checked });

  // ---- pop-up blocker: ban a site forever; its tabs get closed ----
  const renderPop = () => {
    const rec = bg.api.getRecentPops().slice(0, 6), ban = bg.api.getPopupBlock();
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      const tab = tabs[0]; let cur = '';
      try { cur = new URL(tab.url).hostname.replace(/^www\./, '').toLowerCase(); } catch (e) {}
      let h = '';
      if (cur && /\./.test(cur) && !ban.includes(cur)) h += `<div class="card row sp"><div class="s-meta" style="flex:1">${esc(cur)}</div><button class="bad" data-ban="${esc(cur)}" data-close="1">Block this page forever</button></div>`;
      if (rec.length) h += '<div class="mut">Recent pop-ups (tap to ban):</div>' + rec.map(r => `<div class="card row sp"><div class="s-meta" style="flex:1">${esc(r.host)}</div><button class="bad" data-ban="${esc(r.host)}">Ban</button></div>`).join('');
      if (ban.length) h += '<div class="mut" style="margin-top:8px">Banned (' + ban.length + '):</div>' + ban.map(x => `<div class="card row sp"><div class="s-meta" style="flex:1">${esc(x)}</div><button class="sec" data-unban="${esc(x)}">Remove</button></div>`).join('');
      $('pop').innerHTML = h || '<div class="mut">No pop-ups seen yet.</div>';
    });
  };
  $('pop').onclick = async e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.ban) { await bg.api.addPopupBlock(b.dataset.ban); if (b.dataset.close) { chrome.tabs.query({ active: true, currentWindow: true }, t => { if (t[0]) chrome.tabs.remove(t[0].id); }); return; } }
    if (b.dataset.unban) await bg.api.removePopupBlock(b.dataset.unban);
    renderPop();
  };
  renderPop();
  $('dash').onclick = () => { chrome.runtime.openOptionsPage(); window.close(); };
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const tab = tabs[0]; if (!tab || !tab.url) return;
    $('site').onclick = () => { const h = new URL(tab.url).hostname.replace(/^www\./, ''); chrome.tabs.create({ url: chrome.runtime.getURL('options.html') + '?host=' + encodeURIComponent(h) + '#sites' }); window.close(); };
    const ai = bg.api.adInfo(tab.id);
    if (ai.host) {
      $('ad').innerHTML = `<div class="card row sp"><div><div class="s-name">Block ads here</div><div class="s-meta">${esc(ai.host)} · ${ai.count} blocked${ai.global ? '' : ' (global OFF)'}</div></div><label class="sw"><input type="checkbox" ${ai.site ? 'checked' : ''}><i></i></label></div>`;
      $('ad').onchange = e => bg.api.setAdSite(ai.host, e.target.checked).then(() => { $('ad').insertAdjacentHTML('beforeend', '<div class="mut">Reload page to apply.</div>'); });
    }
    const m = bg.api.matching(tab.url);
    const host = new URL(tab.url).hostname.replace(/^www\./, '').toLowerCase();
    $('here').innerHTML = m.map(s => `<div class="card row sp" data-id="${s.id}"><span class="s-name">${esc(s.meta.name)}</span><label class="sw"><input type="checkbox" ${s.enabled && !bg.api.isExcluded(s.id, host) ? 'checked' : ''}><i></i></label></div>`).join('') || '<div class="mut">No scripts match this page.</div>';
    $('here').onchange = e => { const id = e.target.closest('.card').dataset.id, on = e.target.checked; Promise.all([bg.api.setSiteExcluded(id, host, !on), on ? bg.api.setEnabled(id, true) : 0]).then(() => { $('here').insertAdjacentHTML('beforeend', '<div class="mut">Reload page to apply.</div>'); }); };
    chrome.tabs.sendMessage(tab.id, { type: 'getMenu' }, { frameId: 0 }, cmds => {
      if (chrome.runtime.lastError || !cmds || !cmds.length) return;
      $('cmds').innerHTML = '<h2>Script commands</h2>' + cmds.map((c, i) => `<button class="sec" style="display:block;width:100%;margin-bottom:6px;text-align:left" data-i="${i}">${esc(c.name)}<span class="mut"> · ${esc(c.sname)}</span></button>`).join('');
      $('cmds').onclick = e => { const b = e.target.closest('button'); if (!b) return; const c = cmds[+b.dataset.i]; chrome.tabs.sendMessage(tab.id, { type: 'runMenu', ch: c.ch, cmdId: c.cmdId }, { frameId: 0 }); window.close(); };
    });
  });
});
